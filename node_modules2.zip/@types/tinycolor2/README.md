# Installation
> `npm install --save @types/tinycolor2`

# Summary
This package contains type definitions for tinycolor (https://github.com/bgrins/TinyColor).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/tinycolor2.

### Additional Details
 * Last updated: Tue, 12 Sep 2023 12:34:44 GMT
 * Dependencies: none
 * Global values: `tinycolor`

# Credits
These definitions were written by [Mordechai Zuber](https://github.com/M-Zuber), [Geert Jansen](https://github.com/geertjansen), and [Niels van Hoorn](https://github.com/nvh).
