<div align="center">
  <img width="200" height="200"
    src="https://s3.amazonaws.com/pix.iemoji.com/images/emoji/apple/ios-11/256/crayon.png">
  <h1>@jimp/plugins</h1>
  <p>Default Jimp plugins.</p>
</div>

## Included Plugins

- [blit](../plugin-blit)
- [blur](../plugin-blur)
- [color](../plugin-color)
- [contain](../plugin-contain)
- [cover](../plugin-cover)
- [displace](../plugin-displace)
- [dither](../plugin-dither)
- [flip](../plugin-flip)
- [gaussian](../plugin-gaussian)
- [invert](../plugin-invert)
- [mask](../plugin-mask)
- [normalize](../plugin-normalize)
- [print](../plugin-print)
- [resize](../plugin-resize)
- [rotate](../plugin-rotate)
- [scale](../plugin-scale)
